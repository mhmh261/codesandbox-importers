module.exports = {
  extends: 'airbnb',
  plugins: ['react', 'jest'],
};
