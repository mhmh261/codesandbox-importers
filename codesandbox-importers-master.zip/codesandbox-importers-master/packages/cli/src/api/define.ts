import { getParameters } from "codesandbox-import-utils/lib/api/define";

export { getParameters };
