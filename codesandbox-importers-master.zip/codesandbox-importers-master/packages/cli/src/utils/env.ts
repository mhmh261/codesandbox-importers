export const IS_STAGING = process.env.CODESANDBOX_NODE_ENV === "development";
