export const manifest = () => {
  return { version: "15.5.4" };
};
