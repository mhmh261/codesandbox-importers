#!/bin/bash
yarn
yarn build:git-extractor
yarn dev
